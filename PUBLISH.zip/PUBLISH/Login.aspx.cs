﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        if (txtUsername.Text != "admin")
        {
            lblMsg.Text = "Invalid UserName";
            Response.Write("<script>alert('Invalid  UserName!');</script>");
        }
        if (txtPassword.Text != "admin")
        {
            lblMsg.Text = "Invalid Password!";
            Response.Write("<script>alert('Invalid  Password!');</script>");
        }
        if ((txtPassword.Text != "admin") && (txtUsername.Text != "admin"))
        {
            lblMsg.Text = "Invalid Login Credentials!";
            Response.Write("<script>alert('Invalid Login Credentials!');</script>");
        }
        else if ((txtPassword.Text == "admin") && (txtUsername.Text == "admin"))
        {
            Response.Redirect("NewUserEntry.aspx");
        }
    }
}