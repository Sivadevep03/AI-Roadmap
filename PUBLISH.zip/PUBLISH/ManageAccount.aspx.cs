﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class ManageAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           // BindGridView();
        }
    }
   
    public void BindGridView()
    {
        string query = " select row_number() over(order by(select 1) )AS SNO, UL.ID,UL.Address,UL.ContactNo,UL.Date,UL.Status,UL.ProdServID,UL.Username,PS.ProdServiceValues,UL.PrimeIncome,UL.ServiceCost,UL.Others from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status='Successfully Finished' ";
        DataTable dt = new DataTable();
        string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        SqlConnection objSqlConn = new SqlConnection(stringConnStr);

        SqlDataAdapter objSqlDa = new SqlDataAdapter(query, objSqlConn);
        objSqlDa.Fill(dt);
        grdExcel.MasterTableView.ShowHeader = true;
        grdExcel.DataSource = dt;
        grdExcel.DataBind();
       
     
        grdExcel.ExportSettings.ExportOnlyData = false;
        grdExcel.MasterTableView.ExportToExcel();
        //foreach (GridViewRow row in grdUsers.Rows)
        //{
        //    TextBox txtServiceCost = row.FindControl("txtServiceCost") as TextBox;
        //    TextBox txtOthers = row.FindControl("txtOthers") as TextBox;
        //    TextBox txtPrimeIncome = row.FindControl("txtPrimeIncome") as TextBox;
        //    txtServiceCost.Text = row.Cells[8].Text;
        //    txtOthers.Text = row.Cells[9].Text;
        //    txtPrimeIncome.Text = row.Cells[7].Text;
            
        //    txtOthers.Enabled = false;
        //    txtPrimeIncome.Enabled = false;
        //    txtServiceCost.Enabled = false;
        //}


    }

    //protected void btnSave_Click(object sender, EventArgs e)
    //{
    //    foreach (GridViewRow row in grdUsers.Rows)
    //    {
    //        string IDD = grdUsers.DataKeys[row.RowIndex].Value.ToString();
    //       ////int Id = Convert.ToInt32( grdUsers.DataKeys[0].Values[0]);

    //        TextBox txtServiceCost = row.FindControl("txtServiceCost") as TextBox;
    //        TextBox txtOthers = row.FindControl("txtOthers") as TextBox;
    //        TextBox txtPrimeIncome = row.FindControl("txtPrimeIncome") as TextBox;
    //        SqlCommand objSqlCmd = new SqlCommand();
    //        objSqlCmd.CommandText = "update  [UsersList] set [ServiceCost]=@ServiceCost,[Others]=@Others,[PrimeIncome]=@PrimeIncome  where [Id]='" + IDD + "'";

    //        objSqlCmd.Parameters.AddWithValue("@ServiceCost", txtServiceCost.Text);
           

    //        objSqlCmd.Parameters.AddWithValue("@Others", txtOthers.Text);


    //        objSqlCmd.Parameters.AddWithValue("@PrimeIncome", txtPrimeIncome.Text);


    //        SQLInteraction objSqlIntr = new SQLInteraction();
    //        objSqlIntr.ExecuteCmd(objSqlCmd);
    //    }

    //    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "showAlert();", true);
    //}
    //protected void btnEdit_Click(object sender, EventArgs e)
    //{
    //    foreach(GridViewRow row in grdUsers.Rows)
    //    {
    //        TextBox txtServiceCost = row.FindControl("txtServiceCost") as TextBox;
    //        TextBox txtOthers = row.FindControl("txtOthers") as TextBox;
    //        TextBox txtPrimeIncome = row.FindControl("txtPrimeIncome") as TextBox;
    //        txtOthers.Enabled = true;
    //        txtPrimeIncome.Enabled = true;
    //        txtServiceCost.Enabled = true;
    //    }
    //}
    //protected void grdUsers_RowDataBound(object sender, GridViewRowEventArgs e)
    //{

    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        TextBox txtServiceCost = e.Row.FindControl("txtServiceCost") as TextBox;
    //        TextBox txtOthers = e.Row.FindControl("txtOthers") as TextBox;
    //        TextBox txtPrimeIncome = e.Row.FindControl("txtPrimeIncome") as TextBox;
    //        //string NPID0 = e.Row.Cells[0].Text;
    //        //string NPID1 = e.Row.Cells[1].Text;
    //        //string NPID2 = e.Row.Cells[2].Text;
    //        //string NPID3 = e.Row.Cells[3].Text;
    //        //string NPID4 = e.Row.Cells[4].Text;
    //     txtServiceCost.Text = e.Row.Cells[8].Text;
    //    txtOthers .Text= e.Row.Cells[9].Text;
    //        txtPrimeIncome.Text= e.Row.Cells[10].Text;
    //        //string NPID8 = e.Row.Cells[8].Text;

    //    }

    //}

   

    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public static void saveUserCost(UsersList userList)
    {
        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "Update  [UsersList] set [ServiceCost]=@ServiceCost,[Others]=@Others,[PrimeIncome]=@PrimeIncome where [ID]='" + userList.ID + "'";
        objSqlCmd.Parameters.AddWithValue("@ServiceCost", userList.ServiceCost);
        objSqlCmd.Parameters.AddWithValue("@Others", userList.Others);
        objSqlCmd.Parameters.AddWithValue("@PrimeIncome", userList.PrimeIncome);
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }
    protected void btnExport_ServerClick(object sender, EventArgs e)
    {
        BindGridView();
    }
}