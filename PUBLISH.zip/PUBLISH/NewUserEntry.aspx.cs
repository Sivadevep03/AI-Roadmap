﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.UI;
using Telerik.Web.UI;
using System.Net;
using System.Drawing.Imaging;
using System.Drawing;

public partial class NewUserEntry : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //GridBoundColumn column = new GridBoundColumn();
            //this.grdExcel.MasterTableView.Columns.Add(column);
            //column.HeaderText = "SNO";

        }

    }
    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public static void saveAllUsers(UsersList userList)
    {

        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "insert into [UsersList] ([Username],[Address],[ContactNo],[ProdServID],[Status],[Date],[KYC]) values (@Username,@Address,@ContactNo,@ProdServID,@Status,@Date,@KYC)";
        objSqlCmd.Parameters.AddWithValue("@Username", userList.Username);
        objSqlCmd.Parameters.AddWithValue("@Address", userList.Address);
        objSqlCmd.Parameters.AddWithValue("@ContactNo", userList.ContactNo);
        objSqlCmd.Parameters.AddWithValue("@ProdServID", userList.ProdServID);
        objSqlCmd.Parameters.AddWithValue("@Status", userList.Status);
        objSqlCmd.Parameters.AddWithValue("@Date", userList.Date);
        objSqlCmd.Parameters.AddWithValue("@KYC", userList.KYC);
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }
    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false)]
    public static void deleteUser(string UserId)
    {
        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "delete  [UsersList] where [ID]='" + UserId + "'";
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }
    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false)]
    public static void updateUser(UsersList userList)
    {
        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "Update  [UsersList] set [Username]=@Username,[Address]=@Address,[ContactNo]=@ContactNo,[ProdServID]=@ProdServID,[Status]=@Status,[Date]=@Date,[KYC]=@KYC where [ID]='" + userList.ID + "'";
        objSqlCmd.Parameters.AddWithValue("@Username", userList.Username);
        objSqlCmd.Parameters.AddWithValue("@Address", userList.Address);
        objSqlCmd.Parameters.AddWithValue("@ContactNo", userList.ContactNo);
        objSqlCmd.Parameters.AddWithValue("@ProdServID", userList.ProdServID);
        objSqlCmd.Parameters.AddWithValue("@Status", userList.Status);
        objSqlCmd.Parameters.AddWithValue("@Date", userList.Date);
        objSqlCmd.Parameters.AddWithValue("@KYC", userList.KYC);
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }


    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public static void saveKYC(KYC kycDetails)//static method to cvall ajax call
    {
        var data = kycDetails;
        char[] separator = { '\\' };
        string[] filenamearray = data.FileName.Split(separator);
        int length = filenamearray.Length;
        for (int i = 0; i < filenamearray.Length; i++)
        {
            SqlCommand objSqlCmd = new SqlCommand();
            objSqlCmd.CommandText = "insert into [KYC] ([UserID],[FileName]) values (@UserID,@FileName)";
            objSqlCmd.Parameters.AddWithValue("@UserID", kycDetails.UserID);
            objSqlCmd.Parameters.AddWithValue("@FileName", filenamearray[i]);

            SQLInteraction objSqlIntr = new SQLInteraction();
            objSqlIntr.ExecuteCmd(objSqlCmd);


        }

    }
    protected void btnExport_ServerClick(object sender, EventArgs e)
    {
        string query = "";
        if (ddlSearchRec.SelectedValue == "EntryInProcess")
        {


            query = "select row_number() over(order by(select 1) )AS SNO,UL.ID,UL.Address,UL.ContactNo,UL.Date,UL.Status,UL.ProdServID,UL.Username,PS.ProdServiceValues from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status!='Successfully Finished'";
            if (dateSearch.Value != "")
            {
                query += "and UL.[Date]='" + dateSearch.Value + "'";

            }
            //if (txtSearchName.Value != "")
            //{
            //    string name = txtSearchName.Value + "%";
            //    query += "and UL.[Username] like'" + name + "' ";
            //}
            //if (txtSearchContact.Value != "")
            //{
            //    string contact = txtSearchContact.Value + "%";
            //    query += "and UL.[ContactNo] like'" + contact + "'";

            //}


        }
        if (ddlSearchRec.SelectedValue == "ExistingEntry")
        {

            query = "select row_number() over(order by(select 1) )AS SNO, UL.ID,UL.Address,UL.ContactNo,UL.Date,UL.Status,UL.ProdServID,UL.Username,PS.ProdServiceValues from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status='Successfully Finished'";


            if (dateSearch.Value != "")
            {
                query += "and UL.[Date]='" + dateSearch.Value + "'";

            }
            //if (txtSearchName.Value != "")
            //{
            //    string name = txtSearchName.Value + "%";
            //    query += "and UL.[Username] like'" + name + "' ";
            //}
            //if (txtSearchContact.Value != "")
            //{
            //    string contact = txtSearchContact.Value + "%";
            //    query += "and UL.[ContactNo] like'" + contact + "'";

            //}


        }
        DataTable dt = new DataTable();
        string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        SqlConnection objSqlConn = new SqlConnection(stringConnStr);

        SqlDataAdapter objSqlDa = new SqlDataAdapter(query, objSqlConn);
        objSqlDa.Fill(dt);
        //dt.Columns.Add("SNO",typeof(int));
        //  for (int i = 1; i <= dt.Rows.Count;i++ )
        //  {
        //      dt.Rows[i]["SNO"] = i;
        //      i++;
        //  }

        //dt.Columns.Add("SNO", typeof(int));

        //for (int count = 0; count < dt.Rows.Count; count++)
        //{
        //    dt.Rows[count]["SNO"] = count + 1;
        //}
        grdExcel.MasterTableView.ShowHeader = true;
        grdExcel.DataSource = dt;
        grdExcel.DataBind();
        grdExcel.ExportSettings.ExportOnlyData = true;
        grdExcel.MasterTableView.ExportToExcel();


        // Response.Clear();
        // string FileName = "Excel" + DateTime.Now + ".xls";
        // Response.Buffer = true;
        // Response.AddHeader("content-disposition", string.Format("attachment;filename=" + FileName));
        // Response.Charset = "";

        // StringWriter strwriterHead = new StringWriter();
        // HtmlTextWriter htmlwriterHead = new HtmlTextWriter(strwriterHead);
        // Response.Cache.SetCacheability(HttpCacheability.NoCache);
        // Response.ContentType = "application/vnd.ms-excel";

        // gridExcel.HeaderRow.Style.Add("background-color", "#ddd");
        // //gridExcel.GridLines = GridLines.Both;
        ////Page.VerifyRenderingInServerForm(this);
        // gridExcel.RenderControl(htmlwriterHead);
        // Response.Write(strwriterHead.ToString());
        // //Response.Output.Write(Request.Form[hfGridhtml.UniqueID]);
        // Response.Flush();
        // Response.End();



    }
    //protected override void Render(HtmlTextWriter writer)
    //{

    //        Page.VerifyRenderingInServerForm(this);

    //    base.Render(writer);
    //}
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);


    }




    protected void btnDownloadImage_ServerClick(object sender, EventArgs e)
    {
        string url = DownloadimagePath.Value;
        char[] separator = { '/' };
        string[] filenamearray = url.Split(separator);
        string filenameofImage = filenamearray[1];

        string path = HttpContext.Current.Server.MapPath(url);
        Response.ContentType = "image/jpeg";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.AddHeader("Content-Disposition", "attachment;filename=" + filenameofImage);
        Response.TransmitFile(Server.MapPath(url));
        Response.Flush();
        Response.End();
        ClientScript.RegisterStartupScript(this.GetType(), "Popup", "btnAddNew_ClientClick();", true);
        //System.Drawing.Image image = DownloadImageFromUrl(url);\""+name+"\""

        //string rootPath = path;
        //string fileName = System.IO.Path.Combine("@"+rootPath);
        //image.Save(fileName);

    }


    //public System.Drawing.Image DownloadImageFromUrl(string imageUrl)
    //{
    //    System.Drawing.Image image = null;

    //    try
    //    {
    //        System.Net.HttpWebRequest webRequest = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(imageUrl);
    //        webRequest.AllowWriteStreamBuffering = true;
    //        webRequest.Timeout = 30000;

    //        System.Net.WebResponse webResponse = webRequest.GetResponse();

    //        System.IO.Stream stream = webResponse.GetResponseStream();

    //        image = System.Drawing.Image.FromStream(stream);

    //        webResponse.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        return null;
    //    }

    //    return image;
    //}

    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false)]
    public static void downloadImage(string src)
    {
       string url = src;
       // char[] separator = { '/' };
       // string[] filenamearray = url.Split(separator);
       // string filenameofImage ="~\\MediaUploader\\"+ filenamearray[4];

       // string path = HttpContext.Current.Server.MapPath(filenameofImage);
   //HttpContext context = HttpContext.Current;
       // //Response.ContentType = "image/jpeg";
       //context. Response.ContentType = "image/jpeg";
       //context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
       //context.Response.AddHeader("Content-Disposition", "attachment;filename=" + filenameofImage);
       // context.Response.TransmitFile(HttpContext.Current.Server.MapPath(filenameofImage));
       //context. Response.Flush();
       //context. Response.End();
  // ScriptManager.RegisterStartupScript(this.GetType(), "Popup", "btnAddNew_ClientClick();", true);

  //ScriptManager.RegisterStartupScript(context, context.GetType(), "Alert", "alerttmsg('Please provide valid date of creation as the Date has been saved already !');", true);
       //string url = DownloadimagePath.Value;


        
      // char[] separator = { '/' };
      // string[] filenamearray = url.Split(separator);
      // string filenameofImage = filenamearray[4];
      // HttpContext context = HttpContext.Current;
      // string path = HttpContext.Current.Server.MapPath("~\\MediaUploader\\");
      // string path1 = HttpContext.Current.Server.MapPath("~");
      //context. Response.ContentType = "image/jpeg";
      //context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
      //context.Response.AddHeader("Content-Disposition", "attachment;filename=" + filenameofImage);
      //context.Response.TransmitFile(context.Server.MapPath("~"));
      //context.Response.Flush();
      //context.Response.End();


      //WebClient webclient = new WebClient();

      //ScriptManager.RegisterStartupScript(context, context.GetType(), "Alert", "alerttmsg('Please provide valid date of creation as the Date has been saved already !');", true);
       //ClientScript.RegisterStartupScript(this.GetType(), "Popup", "btnAddNew_ClientClick();", true);
    }

}