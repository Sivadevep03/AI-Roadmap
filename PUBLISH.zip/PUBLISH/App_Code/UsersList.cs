﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UsersList
/// </summary>
public class UsersList
{
    public int ID { get; set; }
    public string Username { get; set; }
    public DateTime Date { get; set; }
    public string ContactNo { get; set; }
    public Int32 ProdServID { get; set; }
    public float ServiceCost { get; set; }
    public float Others { get; set; }
    public float PrimeIncome { get; set; }
    public string Address { get; set; }
    public string Status { get; set; }
    public string KYC { get; set; }
	public UsersList()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}