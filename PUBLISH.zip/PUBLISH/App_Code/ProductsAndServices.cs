﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Web.Script.Services;
using System.Collections;





/// <summary>
/// Summary description for ProductsAndServices
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
 [System.Web.Script.Services.ScriptService]
public class ProductsAndServices : System.Web.Services.WebService {

   
    public ProductsAndServices () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }
   
    // public void GetAllProductsAndServices()
    //{
    //    List<Products> listProducts = new List<Products>();
    //         SqlCommand objSqlCmd = new SqlCommand();
    //          objSqlCmd.CommandText
    //              ="Select * from [ProductsAndServices]";
    //     SQLInteraction objSqlIntr = new SQLInteraction();
    //     objSqlIntr.getAllProducts(objSqlCmd);
      
    

    //}
      [WebMethod(EnableSession = true)]
     public  List<Products>   getAllProducts()
     {
         string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
         SqlConnection objSqlConn = new SqlConnection(stringConnStr);
         SqlCommand objSqlCmd = new SqlCommand("Select * from [ProductsAndServices]", objSqlConn);
         //objSqlCmd.CommandText = "Select * from [ProductsAndServices]";
         //objSqlCmd.Connection = con;
         List<Products> listProducts = new List<Products>();

         objSqlConn.Open();
         SqlDataReader rdr = objSqlCmd.ExecuteReader();
         while (rdr.Read())
         {
             Products products = new Products();
             products.ID = Convert.ToInt32(rdr["ID"].ToString());
             products.ProdServiceValues = rdr["ProdServiceValues"].ToString();
             listProducts.Add(products);
         }
         return listProducts;
     }


      [WebMethod(EnableSession = true)]
      public string  getAllUsersForMA()
      {
         
          DataSet ds = new DataSet();
          DataTable objDT = new DataTable();
         
          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
          SqlConnection objSqlConn = new SqlConnection(stringConnStr);
          string query = "select Convert(Varchar(10),UL.Date,105) as Date ,UL.ID,UL.ContactNo,UL.Username,PS.ProdServiceValues,UL.[ServiceCost],UL.[Others],UL.[PrimeIncome] from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status='Successfully Finished' ";
          query += "order by UL.[ID]desc";
          SqlCommand objSqlCmd = new SqlCommand(query, objSqlConn);
          objSqlConn.Open();
          SqlDataAdapter objSqlDa = new SqlDataAdapter(objSqlCmd);
          objSqlDa.Fill(ds, "Users");
          return ds.GetXml();
      }




      [WebMethod(EnableSession = true)]
      public string   getAllUsers(string Status, string datesearch, string namesearch, string contactsearch)
      {
          //writeLog("GetAllUsers Invoked");
          DataSet ds = new DataSet();
          try { 
         
         
          DataTable objDT = new DataTable();
        
          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

         
         
     
         
     
          //writeLog("try block GetAllUsers Invoked"+stringConnStr);
          List<UsersList> listUsers = new List<UsersList>();
          Products products = new Products();
     
          if (Status == "EntryInProcess")
          {
              //writeLog("Entry In Process Records");
              string query = "select Convert(Varchar(10),UL.Date,105) as Date, UL.ID,UL.Address,UL.ContactNo,UL.Status,UL.ProdServID,UL.Username,PS.ProdServiceValues from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status!='Successfully Finished' ";
              if(datesearch!="")
              {
                  query += "and UL.[Date]='"+datesearch+"'";

              }
              if (namesearch != "")
              {
                  string name = namesearch + "%";
                  query += "and UL.[Username] like'" + name + "' ";
              }
              if(contactsearch!="")
              {
                  string contact = contactsearch + "%";
                  query += "and UL.[ContactNo] like'" + contact + "'";

              }
              query += "order by UL.[ID]desc";
              SqlCommand objSqlCmd = new SqlCommand(query, objSqlConn);
              objSqlConn.Open();
            SqlDataAdapter objSqlDa = new SqlDataAdapter(objSqlCmd);
            objSqlDa.Fill(ds, "Users");
          }
          if(Status=="ExistingEntry")
          {
              //writeLog("Existing Entry Records");
              string query = "select Convert(Varchar(10),UL.Date,105) as Date, UL.ID,UL.Address,UL.ContactNo,UL.Status,UL.ProdServID,UL.Username,PS.ProdServiceValues from  [UsersList]UL left outer join [ProductsAndServices]PS on UL.[ProdServID]=PS.[Id] where [UL].Status='Successfully Finished'";


              if (datesearch != "")
              {
                  query += "and UL.[Date]='" + datesearch + "'";

              }
              if (namesearch != "")
              {
                  string name = namesearch + "%";
                  query += "and UL.[Username] like'" + name + "'";
              }
              if (contactsearch != "")
              {
                  string contact = contactsearch + "%";

                  query += "and UL.[ContactNo] like'" + contact + "'";

              }
              query += "order by UL.[ID]desc";
              SqlCommand objSqlCmd = new SqlCommand(query, objSqlConn);
              objSqlConn.Open();
             SqlDataAdapter objSqlDa = new SqlDataAdapter(objSqlCmd);
             objSqlDa.Fill(ds, "Users");
            
          }
          }
          catch (Exception ex)
        {
            writeLog(ex.ToString());
           
        }

          return ds.GetXml();
         // var userArrayList = new ArrayList();
         //foreach(DataRow row in objDT.Rows)
         // {
              
         //     userArrayList.Add(Convert.ToInt32(row["ID"].ToString()));
         //     userArrayList.Add(row["Username"].ToString());
         //     userArrayList.Add (row["Address"].ToString());
         //     userArrayList.Add(row["ContactNo"].ToString());
         //     userArrayList.Add(Convert.ToDateTime(row["Date"].ToString()));
         //     userArrayList.Add(row["Status"].ToString());
         //     userArrayList.Add(Convert.ToInt32(row["ProdServID"].ToString()));
         //     userArrayList.Add(row["ProdServiceValues"].ToString());
             
            
          //}
        
      }

      [WebMethod(EnableSession = true)]
      public string getUser(string UserId)
      {
          DataSet ds = new DataSet();
        string  stringSelQuery = "select * from [UsersList] where [ID]='" + UserId + "'";
       
          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
      
          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds,"Users");
          return ds.GetXml();
      }


     [WebMethod(EnableSession = true)]
      public string getUserImages(string CustomerID)
      {
          DataSet ds = new DataSet();
          string stringSelQuery = "select * from [KYC] where [UserID]='" + CustomerID + "'";

          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds, "Users");
          var xmll = ds.GetXml();
          return ds.GetXml();
      }

      [WebMethod(EnableSession = true)]
      public string getUserCosts(string UserId)
      {
          DataSet ds = new DataSet();
          string stringSelQuery = "select * from [UsersList] where [ID]='" + UserId + "'";

          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds, "Users");
          return ds.GetXml();
      }

      [WebMethod(EnableSession = true)]
      public string getProdServices()
      {
          
          DataSet ds = new DataSet();
          string stringSelQuery = "select * from [ProductsAndServices] ";

          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
         
          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds, "ProdServices");
          //var xmldata = ds.GetXml();
          return ds.GetXml();
      }

      [WebMethod(EnableSession = true)]
      public string getPS(string ID)
      {
          DataSet ds = new DataSet();
          string stringSelQuery = "select * from [ProductsAndServices] where [ID]='" + ID + "'";

          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds, "ProdServices");
          return ds.GetXml();
      }



      private void writeLog(string msg)
      {
          string FileName = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString();
          string fileLoc = "";
          fileLoc = Server.MapPath(".") + "\\LogFile" + FileName + ".log";

          if (!File.Exists(fileLoc))
          {
              FileStream fileStream = System.IO.File.Create(fileLoc);
              StreamWriter swr = new StreamWriter(fileStream);
              swr.Close();
          }

          FileStream fs = new FileStream(fileLoc, FileMode.Append, FileAccess.Write);
          StreamWriter sw = new StreamWriter(fs);
          sw.WriteLine(DateTime.Now.ToString() + " : " + msg);
          sw.Close();
          fs.Close();
          fs.Dispose();


      }

      [WebMethod(EnableSession = true)]
      public string getCountOfServices(string Date,string Status)
      {
          DataSet dscheck = new DataSet();
          DataTable dt = new DataTable();
          dt.Columns.Add("Date");
          dt.Columns.Add("NoOfServices");
         // DataRow row1st = dt.NewRow();
         //DateTime firstdate=Convert.ToDateTime(Date);
         //string datefrmt = firstdate.Day.ToString() + "-" + firstdate.Month.ToString() + "-" + firstdate.Year.ToString();
         //row1st["Date"] = datefrmt;
         // row1st["NoOfServices"] = 0;
         // dt.Rows.Add(row1st);
          for (int i = 1; i <= 7; i++)
          {
              DateTime endDatei = Convert.ToDateTime(Date).AddDays(i);
              string datreformatedi = endDatei.Day.ToString() + "-" + endDatei.Month.ToString() + "-" + endDatei.Year.ToString();

              DataRow rowi = dt.NewRow();
              rowi["Date"] = datreformatedi;
              rowi["NoOfServices"] = 0;
              dt.Rows.Add(rowi);
          }
          dscheck.Tables.Add(dt);
         
          string Startdate = Date;
          DateTime endDateT = Convert.ToDateTime(Date).AddDays(7);
          string datreformatedT = endDateT.Year.ToString()+"-"+ endDateT.Month.ToString()+"-"+ endDateT.Day.ToString();
        
          string stringSelQuery = "select Count(ProdServID) as NoOfServices,Convert (varchar(10),date,105) as Date from UsersList where  Date BETWEEN '" + Startdate + "' and '" + datreformatedT + "' ";
          if (Status == "Enquiry")
          {
              stringSelQuery += "and Status='Enquiry'  group by [Date]";
          }
          if (Status == "Under Process")
          {
              stringSelQuery += "and Status='Under Process'  group by [Date]";
          }
          if (Status == "Follow Up")
          {
              stringSelQuery += "and Status='Follow Up'  group by [Date]";
          }
          if (Status == "Successfully Finished")
          {
              stringSelQuery += "and Status='Successfully Finished'  group by [Date]";
          }
          DataSet ds = new DataSet();
         
          string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

          SqlConnection objSqlConn = new SqlConnection(stringConnStr);

          SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
          objSqlDa.Fill(ds,"Services");

          ////DataSet tempDataset = new DataSet();
          ////tempDataset = ds.Copy();




          //DataSet dstemp = new DataSet();
          //DataTable dttemp = new DataTable();
          //dttemp.Columns.Add("Date");
          //dttemp.Columns.Add("NoOfServices");
         
          //for (int row = 0; row <= ds.Tables[0].Rows.Count - 1; row++)
          //{   DateTime DateFromdb = Convert.ToDateTime(ds.Tables[0].Rows[row]["Date"].ToString());
          //   string DateFormatted = DateFromdb.Year.ToString()+"-"+ DateFromdb.Month.ToString()+"-"+ DateFromdb.Day.ToString();
          //   string NoOfServicesRow = ds.Tables[0].Rows[row]["NoOfServices"].ToString();
          //   DataRow rowi = dttemp.NewRow();
          //   rowi["Date"] = DateFormatted;
          //   rowi["NoOfServices"] = NoOfServicesRow;
          //   dttemp.Rows.Add(rowi);
            
          //}
          //dstemp.Tables.Add(dttemp);
        
          //ds.Clear();

         foreach(DataRow dr in ds.Tables[0].Rows)
         {
             foreach (DataRow drcheck in dscheck.Tables[0].Rows)
              {

                  if (dr["Date"].ToString() == drcheck["Date"].ToString())
                  {
                      string value = dr["NoOfServices"].ToString();
                      drcheck["NoOfServices"] = value;
                      
                  }
                  
              }

          }
         dscheck.DataSetName = "Services";
         ds.Tables[0].Clear();
         ds = dscheck.Copy();
         //var xmldata = dscheck.GetXml();
         //var xmldata2 = ds.GetXml();
         return ds.GetXml();
         
      }
}
