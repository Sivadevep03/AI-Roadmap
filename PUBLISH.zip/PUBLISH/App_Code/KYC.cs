﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for KYC
/// </summary>
public class KYC
{
    public int ID { get; set; }
    public string UserID { get; set; }
    public string FileName { get; set; }
	public KYC()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}