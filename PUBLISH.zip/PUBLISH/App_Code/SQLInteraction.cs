﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for SQLInteraction
/// </summary>
public class SQLInteraction
{

    public SQLInteraction()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable getDataTableFromQuery(string stringSelQuery)
    {
        DataTable objDT = new DataTable();
  

            string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

            SqlConnection objSqlConn = new SqlConnection(stringConnStr);
           
            SqlDataAdapter objSqlDa = new SqlDataAdapter(stringSelQuery, objSqlConn);
         
     
            objSqlDa.Fill(objDT);


      

        return objDT;

    }


 


    public string ExecuteCmd(SqlCommand objSqlCmd)
    {

        string stringConnStr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        SqlConnection objSqlConn = new SqlConnection(stringConnStr);

        objSqlCmd.Connection = objSqlConn;

        objSqlConn.Open();
        objSqlCmd.ExecuteNonQuery();
        objSqlConn.Close();


        return "";
    }
}