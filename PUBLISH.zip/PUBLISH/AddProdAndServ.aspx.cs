﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Web.Script.Services;
using System.Web.UI;
public partial class AddProdAndServ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public static void saveProdAndServ(string prodserv)
    {
        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "insert into [ProductsAndServices] ([ProdServiceValues]) values (@ProdServiceValues)";
        objSqlCmd.Parameters.AddWithValue("@ProdServiceValues", prodserv);
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }
    [WebMethod]
    [ScriptMethodAttribute(UseHttpGet = false)]
    public static void deleteUser(string Id)
    {
        SqlCommand objSqlCmd = new SqlCommand();
        objSqlCmd.CommandText = "delete  [ProductsAndServices] where [ID]='" + Id + "'";
        SQLInteraction objSqlIntr = new SQLInteraction();
        objSqlIntr.ExecuteCmd(objSqlCmd);
    }
}